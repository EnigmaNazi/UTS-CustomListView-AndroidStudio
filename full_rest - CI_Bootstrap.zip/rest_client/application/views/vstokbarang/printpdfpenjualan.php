<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Enigma Stock</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url(); ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url(); ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url(); ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url(); ?>css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      
      <!-- Table -->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Table Penjualan</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>No Penjualan</th>
                  <th>Kode Barang</th>
                  <th>Kode Supplier</th>
                  <th>Nama Pelanggan</th>
                  <th>No Telp Pelanggan</th>
                  <th>Nama Barang</th>
                  <th>Harga Barang</th>
                  <th>Jumlah</th>
                  <th>Keterangan</th>
                  
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>No Penjualan</th>
                  <th>Kode Barang</th>
                  <th>Kode Supplier</th>
                  <th>Nama Pelanggan</th>
                  <th>No Telp Pelanggan</th>
                  <th>Nama Barang</th>
                  <th>Harga Barang</th>
                  <th>Jumlah</th>
                  <th>Keterangan</th>
                  
                </tr>
              </tfoot>
              <tbody>
                
                <?php
                    foreach ($datapenjualan  as $penjualan){
                        echo "<tr>
                              <td>$penjualan->no_penjualan</td>
                              <td>$penjualan->kode_barang</td>
                              <td>$penjualan->kode_supplier</td>
                              <td>$penjualan->nama_pelanggan</td>
                              <td>$penjualan->no_telp_pelanggan</td>
                              <td>$penjualan->nama_barang</td>
                              <td>$penjualan->harga_barang</td>
                              <td>$penjualan->jumlah</td>
                              <td>$penjualan->keterangan</td>
                              
                              </tr>";
                    }
                ?>
              </tbody>
            </table>
          </div>
          
        </div>
      </div>
    </div>
    
    
    
</body>

</html>
<script>
window.print();
</script>