<?php
Class Supplier extends CI_Controller{
    
    var $API ="";
    
    function __construct() {
        parent::__construct();
        $this->API="http://localhost/rest_server/index.php";
        $this->load->library('session');
        $this->load->library('curl');
        $this->load->helper('form');
        $this->load->helper('url');
    }
    
    // menampilkan data kontak
    function index(){
        $data['datasupplier'] = json_decode($this->curl->simple_get($this->API.'/supplier'));
        $this->load->view('vstokbarang/supplier',$data);
    }
    
    // insert data kontak
    function create(){
       
        if(isset($_POST['submit'])){
            $data = array(
                'no_supplier'   =>  $this->input->post('no_supplier'),
                'nama_supplier' =>  $this->input->post('nama_supplier'),
                'no_telp'       =>  $this->input->post('no_telp'),
                'alamat'        =>  $this->input->post('alamat'));


            
            $insert =  $this->curl->simple_post($this->API.'/supplier', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($insert)
            {
                $this->session->set_flashdata('hasil','Insert Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Insert Data Gagal');
            }
            redirect('supplier');
        }else{
            $this->load->view('vstokbarang/tambahsupplier');
        }
    }
    
    // edit data kontak
    function edit(){
        if(isset($_POST['submit'])){
            $data = array(
                'no_supplier'   =>  $this->input->post('no_supplier'),
                'nama_supplier' =>  $this->input->post('nama_supplier'),
                'no_telp'       =>  $this->input->post('no_telp'),
                'alamat'        =>  $this->input->post('alamat'));


            $update =  $this->curl->simple_put($this->API.'/supplier', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($update)
            {
                $this->session->set_flashdata('hasil','Update Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Update Data Gagal');
            }
            redirect('supplier'); 
        }else{
            $params = array('no_supplier'=>  $this->uri->segment(4));
            $data['datasupplier'] = json_decode($this->curl->simple_get($this->API.'/supplier',$params));
            $this->load->view('vstokbarang/editsupplier',$data);
        }
    }
    
    // delete data kontak
    function delete($no_supplier){
        if(empty($no_supplier)){
            redirect('supplier');
        }else{
            $delete =  $this->curl->simple_delete($this->API.'/supplier', array('no_supplier'=>$supplier), array(CURLOPT_BUFFERSIZE => 10)); 
            if($delete)
            {
                $this->session->set_flashdata('hasil','Delete Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Delete Data Gagal');
            }
            redirect('supplier');
        }
    }
    function createpdf(){
        $data['datasupplier'] = json_decode($this->curl->simple_get($this->API.'/supplier'));
        $this->load->view('vstokbarang/printpdfsupplier',$data);
    }
}
?>