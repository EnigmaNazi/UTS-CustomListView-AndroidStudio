<?php
Class Penjualan extends CI_Controller{
    
    var $API ="";
    
    function __construct() {
        parent::__construct();
        $this->API="http://localhost/rest_server/index.php";
        $this->load->library('session');
        $this->load->library('curl');
        $this->load->helper('form');
        $this->load->helper('url');
    }
    
    // menampilkan data kontak
    function index(){
        $data['datapenjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
        $this->load->view('vstokbarang/penjualan',$data);
    }
    
    // insert data kontak
    function create(){
        $data2 = json_decode($this->curl->simple_get($this->API.'/barang'));
        if(isset($_POST['submit'])){
            $data = array(
                'no_penjualan'      =>  $this->input->post('no_penjualan'),
                'kode_barang'       =>  $this->input->post('kode_barang'),
                'kode_supplier'     =>  $this->input->post('kode_supplier'),
                'nama_pelanggan'    =>  $this->input->post('nama_pelanggan'),
                'no_telp_pelanggan' =>  $this->input->post('no_telp_pelanggan'),
                'nama_barang'       =>  $this->input->post('nama_barang'),
                'harga_barang'      =>  $this->input->post('harga_barang'),
                'jumlah'            =>  $this->input->post('jumlah'),
                'keterangan'        =>  $this->input->post('keterangan'));
            
            $insert =  $this->curl->simple_post($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($insert)
            {
                $this->session->set_flashdata('hasil','Insert Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Insert Data Gagal');
            }
            redirect('penjualan');
        }else{
            $this->load->view('vstokbarang/tambahpenjualan',$data2);
        }
    }
    
    // edit data kontak
    function edit(){
        if(isset($_POST['submit'])){
            $data = array(
                'no_penjualan'       =>  $this->input->post('no_penjualan'),
                'kode_barang'       =>  $this->input->post('kode_barang'),
                'kode_supplier'     =>  $this->input->post('kode_supplier'),
                'nama_pelanggan'    =>  $this->input->post('nama_pelanggan'),
                'no_telp_pelanggan' =>  $this->input->post('no_telp_pelanggan'),
                'nama_barang'       =>  $this->input->post('nama_barang'),
                'harga_barang'      =>  $this->input->post('harga_barang'),
                'jumlah'            =>  $this->input->post('jumlah'),
                'keterangan'        =>  $this->input->post('keterangan'));
            
            $update =  $this->curl->simple_put($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($update)
            {
                $this->session->set_flashdata('hasil','Update Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Update Data Gagal');
            }
            redirect('penjualan');
        }else{
            $params = array('no_penjualan'=>  $this->uri->segment(4));
            $data['datapenjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan',$params));
            $this->load->view('vstokbarang/editpenjualan',$data);
        }
    }
    
    // delete data kontak
    function delete($no_penjualan){
        if(empty($no_penjualan)){
            redirect('penjualan');
        }else{
            $delete =  $this->curl->simple_delete($this->API.'/penjualan', array('no_penjualan'=>$penjualan), array(CURLOPT_BUFFERSIZE => 10)); 
            if($delete)
            {
                $this->session->set_flashdata('hasil','Delete Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Delete Data Gagal');
            }
            redirect('penjualan');
        }
    }

    function createpdf(){
        $data['datapenjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
        $this->load->view('vstokbarang/printpdfpenjualan',$data);
    }
    
}
?>