<?php

Class Home extends CI_Controller{

	function __construct() {
        parent::__construct();
       
        $this->load->library('session');
        $this->load->library('curl');
        $this->load->helper('form');
        $this->load->helper('url');
    }
	function index(){
       
        $this->load->view('vstokbarang/home');
    }
}
?>
