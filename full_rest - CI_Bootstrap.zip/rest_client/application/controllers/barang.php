<?php
Class Barang extends CI_Controller{
    
    var $API ="";
    
    function __construct() {
        parent::__construct();
        $this->API="http://localhost/rest_server/index.php";
        $this->load->library('session');
        $this->load->library('curl');
        $this->load->helper('form');
        $this->load->helper('url');
    }
    
    // menampilkan data kontak
    function index(){
        $data['databarang'] = json_decode($this->curl->simple_get($this->API.'/barang'));
        $this->load->view('vstokbarang/barang',$data);
    }
    
    // insert data kontak
    function create(){
        if(isset($_POST['submit'])){
            $data = array(
                'kode_barang'       =>  $this->input->post('kode_barang'),
                'nama_barang'       =>  $this->input->post('nama_barang'),
                'harga_barang'      =>  $this->input->post('harga_barang'),
                'stok_barang'       =>  $this->input->post('stok_barang'));
            
            $insert =  $this->curl->simple_post($this->API.'/barang', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($insert)
            {
                $this->session->set_flashdata('hasil','Insert Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Insert Data Gagal');
            }
            redirect('barang');
        }else{
            $this->load->view('vstokbarang/tambahbarang');
        }
    }
    
    // edit data kontak
    function edit(){
        if(isset($_POST['submit'])){
            $data = array(
                'kode_barang'       =>  $this->input->post('kode_barang'),
                'nama_barang'       =>  $this->input->post('nama_barang'),
                'harga_barang'      =>  $this->input->post('harga_barang'),
                'stok_barang'       =>  $this->input->post('stok_barang'));


            $update =  $this->curl->simple_put($this->API.'/barang', $data, array(CURLOPT_BUFFERSIZE => 10)); 
            if($update)
            {
                $this->session->set_flashdata('hasil','Update Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Update Data Gagal');
            }
            redirect('barang');
        }else{
            $params = array('kode_barang'=>  $this->uri->segment(4));
            $data['databarang'] = json_decode($this->curl->simple_get($this->API.'/barang',$params));
            $this->load->view('vstokbarang/editbarang',$data);
        }
    }
    
    // delete data kontak
    function delete($kode_barang){
        if(empty($kode_barang)){
            redirect('barang');
        }else{
            $delete =  $this->curl->simple_delete($this->API.'/barang', array('kode_barang'=>$kode_barang), array(CURLOPT_BUFFERSIZE => 10)); 
            if($delete)
            {
                $this->session->set_flashdata('hasil','Delete Data Berhasil');
            }else
            {
               $this->session->set_flashdata('hasil','Delete Data Gagal');
            }
            redirect('barang');
        }
    }
    
    // prin to pdf
    function createpdf(){
        $data['databarang'] = json_decode($this->curl->simple_get($this->API.'/barang'));
        $this->load->view('vstokbarang/printpdfbarang',$data);
        
    }
}
?>