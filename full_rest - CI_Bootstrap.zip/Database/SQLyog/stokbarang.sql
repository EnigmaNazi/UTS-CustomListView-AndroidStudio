/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.7.17-log : Database - stokbarang
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`stokbarang` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `stokbarang`;

/*Table structure for table `barang` */

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kode_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga_barang` bigint(20) DEFAULT NULL,
  `stok_barang` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `barang` */

insert  into `barang`(`kode_barang`,`nama_barang`,`harga_barang`,`stok_barang`) values (1,'ROG STRIX GL553VD',16000000,12),(2,'ACER E5475G 5574',6500000,13),(4,'afsasgsdg',6000000,3);

/*Table structure for table `penjualan` */

DROP TABLE IF EXISTS `penjualan`;

CREATE TABLE `penjualan` (
  `no_penjualan` bigint(20) NOT NULL AUTO_INCREMENT,
  `kode_barang` bigint(20) DEFAULT NULL,
  `kode_supplier` bigint(20) DEFAULT NULL,
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `no_telp_pelanggan` varchar(13) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga_barang` bigint(20) DEFAULT NULL,
  `jumlah` bigint(20) DEFAULT NULL,
  `keterangan` text,
  PRIMARY KEY (`no_penjualan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `penjualan` */

insert  into `penjualan`(`no_penjualan`,`kode_barang`,`kode_supplier`,`nama_pelanggan`,`no_telp_pelanggan`,`nama_barang`,`harga_barang`,`jumlah`,`keterangan`) values (1,1,2,'Reymadhan','081280551978','ASUS ROG GL553VD',16000000,2,NULL),(2,2,2,'Bedjoe','089912326770','ACER E5475G 5574',6000000,4,NULL),(4,1,1,'Wedos','08990909790','ASUS ROG GL553VD',16000000,1,'');

/*Table structure for table `supplier` */

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `no_supplier` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_supplier` varchar(100) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `alamat` text,
  PRIMARY KEY (`no_supplier`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `supplier` */

insert  into `supplier`(`no_supplier`,`nama_supplier`,`no_telp`,`alamat`) values (1,'Rey','082280551970','Kedaton'),(2,'Hans','89912219880','Palapa'),(3,'fswfsf','4234235252','afasfasdfasf');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
