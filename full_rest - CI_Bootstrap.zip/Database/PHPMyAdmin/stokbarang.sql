-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 19, 2018 at 06:55 PM
-- Server version: 5.7.17-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stokbarang`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kode_barang` bigint(20) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga_barang` bigint(20) DEFAULT NULL,
  `stok_barang` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `harga_barang`, `stok_barang`) VALUES
(1, 'ROG STRIX GL553VD', 16000000, 12),
(2, 'ACER E5475G 5574', 6500000, 13),
(4, 'afsasgsdg', 6000000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `no_penjualan` bigint(20) NOT NULL,
  `kode_barang` bigint(20) DEFAULT NULL,
  `kode_supplier` bigint(20) DEFAULT NULL,
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `no_telp_pelanggan` varchar(13) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga_barang` bigint(20) DEFAULT NULL,
  `jumlah` bigint(20) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`no_penjualan`, `kode_barang`, `kode_supplier`, `nama_pelanggan`, `no_telp_pelanggan`, `nama_barang`, `harga_barang`, `jumlah`, `keterangan`) VALUES
(1, 1, 2, 'Reymadhan', '081280551978', 'ASUS ROG GL553VD', 16000000, 2, NULL),
(2, 2, 2, 'Bedjoe', '089912326770', 'ACER E5475G 5574', 6000000, 4, NULL),
(4, 1, 1, 'Wedos', '08990909790', 'ASUS ROG GL553VD', 16000000, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `no_supplier` bigint(20) NOT NULL,
  `nama_supplier` varchar(100) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`no_supplier`, `nama_supplier`, `no_telp`, `alamat`) VALUES
(1, 'Rey', '082280551970', 'Kedaton'),
(2, 'Hans', '89912219880', 'Palapa'),
(3, 'fswfsf', '4234235252', 'afasfasdfasf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`no_penjualan`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`no_supplier`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `kode_barang` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `no_penjualan` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `no_supplier` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
