<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Barang extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data barang
    function index_get() {
        $kode_barang = $this->get('kode_barang');
        if ($kode_barang == '') {
            $barang = $this->db->get('barang')->result();
        } else {
            $this->db->where('kode_barang', $kode_barang);
            $barang = $this->db->get('barang')->result();
        }
        $this->response($barang, 200);
    }

    function index_post() {
       

        $data = array(
                    'kode_barang'       => $this->post('kode_barang'),
                    'nama_barang'     => $this->post('nama_barang'),
                    'harga_barang'    => $this->post('harga_barang'),
                    'stok_barang'       => $this->post('stok_barang'));

        $insert = $this->db->insert('barang', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_put() {
        $kode_barang = $this->put('kode_barang');
        $data = array(
                    'kode_barang'       => $this->put('kode_barang'),
                    'nama_barang'     => $this->put('nama_barang'),
                    'harga_barang'    => $this->put('harga_barang'),
                    'stok_barang'       =>$this->put('stok_barang'));
        $this->db->where('kode_barang', $kode_barang);
        $update = $this->db->update('barang', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_delete() {
        $kode_barang = $this->delete('kode_barang');
        $this->db->where('kode_barang', $kode_barang);
        $delete = $this->db->delete('barang');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    //Masukan function selanjutnya disini
}
?>